from .main import main

__version__ = "0.4.0"
