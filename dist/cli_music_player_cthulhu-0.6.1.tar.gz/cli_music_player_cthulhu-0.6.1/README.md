# CLI Music Player (Cthulhu Edition)

A powerful, lightweight terminal-based music player written in Python. It combines a robust local file browser with online streaming capabilities (YouTube, SoundCloud) and a unique visual style featuring a pulsing Cthulhu and synced lyrics.

![Demo](demo.gif)

## Features

- **Hybrid Playback:**
  - **Local:** Plays MP3, FLAC, OGG, WAV, M4A, and more.
  - **Online:** Search and stream directly from **YouTube** and **SoundCloud**.
- **Robust Engine:** Uses `mpv` as the core backend for best-in-class format support and stability.
- **Visuals:**
  - Pulsing Cthulhu animation.
  - **Synced Lyrics:** Automatic fetching from LRCLib with fallback to Letras.mus.br and Lyrics.ovh.
- **Smart Interface:**
  - **Recursive Library:** Scan entire folder trees.
  - **Search Mode:** Press `/` to find online tracks instantly.
  - **Persistence:** Save your default music directory.
- **Cross-Platform:**
  - **Linux:** Works with system `mpv`.
  - **Windows:** Automatically downloads a portable `mpv` if missing.

## Installation

### Via PIP (Recommended)

```bash
pip install cli-music-player-cthulhu
```

### Requirements

- **Python 3.8+**
- **Linux:** You must install `mpv` (e.g., `sudo pacman -S mpv` or `sudo apt install mpv`).
- **Windows:** No extra steps! The player downloads a standalone `mpv` on first run if needed.

## Usage

Run the player:

```bash
musicplayer
# OR open a specific folder:
musicplayer /path/to/music
```

### Controls

| Key | Action |
| :--- | :--- |
| **Arrow Up/Down** | Navigate files / Scroll Lyrics |
| **Enter** | Play file / Open directory / Select Search Result |
| **Space** | Play / Pause |
| **/** | **Search Online** (YouTube default, use `sc:` for SoundCloud) |
| **l** | Toggle Lyrics / Cthulhu View |
| **D** (Shift+d) | **Set current directory as Default** (Persistent) |
| **n** | Next Track |
| **p** | Previous Track (History-aware) |
| **z** | Toggle Shuffle Mode |
| **R** (Shift+r) | Load Recursive Library (all subfolders) |
| **B** (Shift+b) | Return to Browser Mode |
| **+ / -** | Volume Up / Down |
| **Tab** | Toggle "Now Playing" View |
| **s** | Stop |
| **q** | Quit (or go back) |

## Advanced Search

- **YouTube:** Just type your query (e.g., `Coldplay Yellow`).
- **SoundCloud:** Prefix with `sc:` (e.g., `sc:Synthwave mix`).

## License

MIT
